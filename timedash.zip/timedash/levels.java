package nevagonlose.timedash;

import android.graphics.Bitmap;

/**
 * Created by Zi on 2016-08-31.
 */


public class levels {
    public float x;
    public float y;
    public float height;
    public float width;
}

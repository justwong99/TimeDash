package nevagonlose.timedash;

/**
 * Created by Zi on 2016-08-26.
 */


public class button {
    public float x;
    public float y;
    public float height;
    public float width;
    public boolean clicked = false;

    public void detectClick(float posX, float posY){

    }

    public void ambientMove(float sw, float sh){

    }
}
